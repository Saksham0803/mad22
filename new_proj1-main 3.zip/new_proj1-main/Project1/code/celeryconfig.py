broker_url = 'redis://localhost:6379/1'  #msg will be stored
result_backend = 'redis://localhost:6379/2' #result of the message will be stored