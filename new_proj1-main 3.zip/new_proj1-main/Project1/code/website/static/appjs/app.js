import router from "./router.js"

const a = new Vue({
    el : "#app",
    delimiters: ['${','}'],
    router: router,
    data: {

    },
    methods: {

    }
})